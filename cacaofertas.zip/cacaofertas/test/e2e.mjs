// Teste ponta a ponta: sobe servidores falsos (Shopee + Telegram + webhook) em localhost
// e roda o bot de verdade contra eles. Não usa internet nem credenciais reais.
import http from 'node:http';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { execFile, spawn } from 'node:child_process';
import net from 'node:net';
import { promisify } from 'node:util';
import { mkdtempSync, readFileSync, existsSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const APP_ID = '123456';
const SECRET = 'segredo-de-teste';

const node = (id, rate, extra = {}) => ({
  itemId: id,
  productName: `Produto ${id} <teste> & cia`,
  price: '50.00',
  priceMin: '50.00',
  priceMax: '50.00',
  commissionRate: rate,
  sales: 120,
  imageUrl: `http://img.test/${id}.jpg`,
  shopName: 'Loja',
  productLink: `https://shopee.com.br/p/${id}`,
  offerLink: `https://s.shopee.com.br/aff${id}`,
  ratingStar: '4.8',
  priceDiscountRate: 20,
  ...extra,
});

const nodes = [
  node('1', '0.10'),
  node('2', '0.01'), // comissão baixa: deve ser filtrado
  node('3', '0.12', { imageUrl: 'http://img.test/bad.jpg' }), // foto falha: cai para texto
  node('4', '0.08'),
  node('5', '0.09', { offerLink: null }), // sem link de afiliado: deve ser ignorado
  node('6', '0.20'), // passaria, mas MAX_PER_RUN=3 corta
];

const calls = { shopee: 0, photo: [], message: [], webhook: [], keywords: [], paged: 0 };
let sigOk = true;

let base = '';
const server = http.createServer((req, res) => {
  let body = '';
  req.on('data', (c) => (body += c));
  req.on('end', () => {
    const json = (o, s = 200) => {
      res.writeHead(s, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify(o));
    };
    if (req.url === '/paged') {
      calls.paged++;
      const page = JSON.parse(body).variables.page;
      const mkn = (id) => node(String(id), '0.10');
      return json({
        data: { productOfferV2: { nodes: [mkn(page * 10 + 1), mkn(page * 10 + 2)], pageInfo: { page, limit: 2, hasNextPage: page < 5 } } },
      });
    }
    if (req.url === '/partial') {
      const v = JSON.parse(body).variables;
      if (v.sortType === 5) return json({ errors: [{ message: 'boom', extensions: { code: 99 } }] });
      return json({ data: { productOfferV2: { nodes: [node('71', '0.10'), node('72', '0.10')], pageInfo: { page: 1, limit: 2, hasNextPage: false } } } });
    }
    if (req.url === '/graphql') {
      calls.shopee++;
      try {
        calls.keywords.push(JSON.parse(body).variables.keyword);
      } catch {}
      const m = /^SHA256 Credential=(\d+), Timestamp=(\d+), Signature=([0-9a-f]{64})$/.exec(
        req.headers.authorization || '',
      );
      const expected = m && createHash('sha256').update(`${m[1]}${m[2]}${body}${SECRET}`).digest('hex');
      if (!m || m[1] !== APP_ID || m[3] !== expected) sigOk = false;
      const withImg = nodes.map((n) => ({ ...n, imageUrl: n.imageUrl.replace('http://img.test/', `${base}/pic/`) }));
      return json({ data: { productOfferV2: { nodes: withImg, pageInfo: { page: 1, limit: 50, hasNextPage: false } } } });
    }
    if (req.url.endsWith('/sendPhoto')) {
      const b = JSON.parse(body);
      if (b.photo.includes('bad')) return json({ ok: false, description: 'wrong file identifier' }, 400);
      calls.photo.push(b);
      return json({ ok: true, result: {} });
    }
    if (req.url.endsWith('/sendMessage')) {
      calls.message.push(JSON.parse(body));
      return json({ ok: true, result: {} });
    }
    if (req.url.startsWith('/pic/')) {
      if (req.url.includes('bad')) return json({ error: 'sem imagem' }, 404);
      res.writeHead(200, { 'Content-Type': 'image/jpeg' });
      return res.end(Buffer.from([0xff, 0xd8, 0xff, 0xd9]));
    }
    if (req.url === '/hook') {
      calls.webhook.push(JSON.parse(body));
      return json({ ok: true });
    }
    json({ ok: false }, 404);
  });
});

await new Promise((r) => server.listen(0, '127.0.0.1', r));
base = `http://127.0.0.1:${server.address().port}`;
const dir = mkdtempSync(join(tmpdir(), 'shopee-bot-'));
const stateFile = join(dir, 'state.json');
const pageFile = join(dir, 'ofertas.html');
const manualFile = join(dir, 'manuais.json');

const baseEnv = {
  PATH: process.env.PATH,
  SHOPEE_APP_ID: APP_ID,
  SHOPEE_APP_SECRET: SECRET,
  SHOPEE_ENDPOINT: `${base}/graphql`,
  TELEGRAM_API: base,
  TELEGRAM_BOT_TOKEN: 'TOKEN',
  TELEGRAM_CHAT_IDS: '111,222',
  WEBHOOK_URL: `${base}/hook`,
  MIN_COMMISSION_PERCENT: '5',
  MAX_PER_RUN: '3',
  RANK_BY: 'api',
  SORT_TYPES: '5',
  DELAY_SECONDS: '0',
  STATE_FILE: stateFile,
  PAGE_FILE: pageFile,
  MANUAL_FILE: manualFile,
};

const execFileP = promisify(execFile);
// Assíncrono de propósito: o servidor falso roda neste mesmo processo e precisa responder.
const run = async (extra = {}, args = ['--once']) =>
  (await execFileP(process.execPath, [join(root, 'src/bot.js'), ...args], { env: { ...baseEnv, ...extra } })).stdout;

const runAsync = run;

// 1) primeira execução: envia 3 ofertas (1, 3 e 4) para 2 chats + webhook
let out = await runAsync();
assert.ok(sigOk, 'assinatura da Shopee inválida');
assert.equal(calls.shopee, 1);
assert.equal(calls.photo.length, 4, 'ofertas 1 e 4 com foto nos 2 chats'); // 2 produtos x 2 chats
assert.equal(calls.message.length, 2, 'oferta 3 cai para texto nos 2 chats');
assert.equal(calls.webhook.length, 3);
assert.match(calls.photo[0].caption, /&lt;teste&gt; &amp; cia/, 'HTML escapado');
assert.match(calls.photo[0].caption, /R\$\s?50,00/);
assert.match(calls.webhook[0].text, /\*Produto 1/);
assert.ok(calls.webhook.every((w) => w.link.startsWith('https://s.shopee.com.br/aff')));
const ids = Object.keys(JSON.parse(readFileSync(stateFile, 'utf8')).sent).sort();
assert.deepEqual(ids, ['1', '3', '4']);
assert.match(out, /3\/3 ofertas enviadas/);

// página para copiar e colar
const html = readFileSync(pageFile, 'utf8');
assert.equal((html.match(/class="card"/g) || []).length, 3, 'página com 3 cartões');
assert.match(html, /wa\.me\/\?text=/);
assert.match(html, /&lt;teste&gt; &amp; cia/, 'HTML da página escapado');
assert.ok(!html.includes('<teste>'));

// 2) segunda execução: 1, 3 e 4 já foram enviados; sobra só a oferta 6 (as demais são filtradas)
const before = calls.webhook.length;
out = await runAsync();
assert.equal(calls.webhook.length, before + 1);
assert.equal(calls.webhook.at(-1).product.id, '6');
assert.equal((readFileSync(pageFile, 'utf8').match(/class="card"/g) || []).length, 4, 'página acumula ofertas');

// 3) terceira execução: nada novo
const before3 = calls.webhook.length;
out = await runAsync();
assert.equal(calls.webhook.length, before3);
assert.match(out, /nenhuma oferta nova/);

// 4) dry-run não envia nem grava estado
const dryState = join(dir, 'dry.json');
const photos = calls.photo.length;
out = await runAsync({ STATE_FILE: dryState }, ['--once', '--dry-run']);
assert.equal(calls.photo.length, photos);
assert.ok(!existsSync(dryState) || Object.keys(JSON.parse(readFileSync(dryState, 'utf8')).sent).length === 0);
assert.match(out, /\[dry-run\]/);

// 4b) só a página, sem Telegram nem webhook (o caso do WhatsApp copiar e colar)
const onlyPage = join(dir, 'so-pagina.html');
const hooks = calls.webhook.length;
const msgs = calls.photo.length + calls.message.length;
await run({ TELEGRAM_BOT_TOKEN: '', TELEGRAM_CHAT_IDS: '', WEBHOOK_URL: '', PAGE_FILE: onlyPage, STATE_FILE: join(dir, 'outro.json') });
assert.equal(calls.webhook.length, hooks);
assert.equal(calls.photo.length + calls.message.length, msgs);
assert.equal((readFileSync(onlyPage, 'utf8').match(/class="card"/g) || []).length, 3);

// 4c) rotação de palavras-chave entre ciclos e nome configurável
const kwState = join(dir, 'kw.json');
const kwPage = join(dir, 'kw.html');
calls.keywords.length = 0;
for (let i = 0; i < 3; i++) {
  await run({ KEYWORDS: 'fone, air fryer', STATE_FILE: kwState, PAGE_FILE: kwPage, BOT_NAME: 'MeuBot' });
}
assert.deepEqual(calls.keywords, ['fone', 'air fryer', 'fone'], 'alterna as palavras-chave');
assert.match(readFileSync(kwPage, 'utf8'), /<title>MeuBot<\/title>/, 'nome configurável');

// 4d) ranking: sem filtros, junta ordenações, não duplica e envia as melhores pela nota
const rkState = join(dir, 'rk.json');
const rkPage = join(dir, 'rk.html');
const sh0 = calls.shopee;
const wh0 = calls.webhook.length;
await run({ RANK_BY: 'score', SORT_TYPES: '2,5', MAX_PER_RUN: '2', STATE_FILE: rkState, PAGE_FILE: rkPage });
assert.equal(calls.shopee - sh0, 2, 'uma consulta por ordenação');
assert.deepEqual(calls.webhook.slice(wh0).map((w) => w.product.id), ['6', '3'], 'melhores pela nota, sem duplicar');

// 4e) sem filtros nenhum produto com offerLink é descartado (só ordena)
const nfState = join(dir, 'nf.json');
const wh1 = calls.webhook.length;
await run({ RANK_BY: 'score', MIN_COMMISSION_PERCENT: '0', MAX_PER_RUN: '20', STATE_FILE: nfState, PAGE_FILE: join(dir, 'nf.html') });
assert.deepEqual(
  calls.webhook.slice(wh1).map((w) => w.product.id).sort(),
  ['1', '2', '3', '4', '6'],
  'sem filtro entram todos que têm link de afiliado',
);

// 4f) paginação: continua além de MAX_PAGES quando faltam ofertas novas
const pgPaged = calls.paged;
await run({ SHOPEE_ENDPOINT: `${base}/paged`, MAX_PAGES: '1', MAX_PAGES_LIMIT: '5', MAX_PER_RUN: '5', MIN_COMMISSION_PERCENT: '0', STATE_FILE: join(dir, 'pg.json'), PAGE_FILE: join(dir, 'pg.html') });
assert.equal(calls.paged - pgPaged, 3, 'pagina até juntar ofertas suficientes (2+2+2)');

// 4g) se uma ordenação falha, as outras ainda são enviadas
const wh2 = calls.webhook.length;
out = await run({ SHOPEE_ENDPOINT: `${base}/partial`, SORT_TYPES: '2,5', MIN_COMMISSION_PERCENT: '0', STATE_FILE: join(dir, 'pt.json'), PAGE_FILE: join(dir, 'pt.html') });
assert.equal(calls.webhook.length - wh2, 2, 'envia o que conseguiu buscar');
assert.match(out, /falha ao consultar a Shopee/);

// 5) configuração inválida sai com erro claro
let failed = false;
try {
  await run({ SHOPEE_APP_SECRET: '' });
} catch (e) {
  failed = true;
  assert.match(String(e.stderr), /SHOPEE_APP_SECRET não definido/);
}
assert.ok(failed, 'deveria falhar sem SHOPEE_APP_SECRET');
failed = false;
try {
  await run({ RANK_BY: 'xyz' });
} catch (e) {
  failed = true;
  assert.match(String(e.stderr), /RANK_BY inválido/);
}
assert.ok(failed, 'RANK_BY inválido deve falhar');

// 6) modo contínuo: página em localhost + proxy de imagem
const freePort = await new Promise((r) => {
  const s = net.createServer().listen(0, '127.0.0.1', () => {
    const { port } = s.address();
    s.close(() => r(port));
  });
});
const child = spawn(process.execPath, [join(root, 'src/bot.js')], {
  env: { ...baseEnv, PAGE_PORT: String(freePort) },
});
await new Promise((resolve, reject) => {
  const timer = setTimeout(() => reject(new Error('servidor local não subiu')), 15000);
  child.stdout.on('data', (d) => {
    if (String(d).includes('página disponível')) {
      clearTimeout(timer);
      resolve();
    }
  });
});
const local = `http://127.0.0.1:${freePort}`;
const page = await (await fetch(`${local}/`)).text();
assert.match(page, /Copiar imagem/);
assert.match(page, /\/img\/1/);
const img = await fetch(`${local}/img/1`);
assert.equal(img.status, 200);
assert.equal(img.headers.get('content-type'), 'image/jpeg');
assert.equal((await fetch(`${local}/img/3`)).status, 502, 'imagem quebrada vira 502');
assert.equal((await fetch(`${local}/img/999`)).status, 404, 'id fora da página não é servido');
assert.equal((await fetch(`${local}/qualquer`)).status, 404);

// 7) oferta manual (Mercado Livre / Amazon)
const post = (body, headers = {}) =>
  fetch(`${local}/api/manual`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', ...headers },
    body: typeof body === 'string' ? body : JSON.stringify(body),
  });
let r = await post({ store: 'Mercado Livre', name: 'Cadeira <Gamer>', price: '599,90', link: 'https://mercadolivre.com/sec/abc', image: `${base}/pic/9.jpg` });
assert.equal(r.status, 200);
const mid = (await r.json()).id;
assert.match(mid, /^m/);
const page2 = await (await fetch(`${local}/`)).text();
assert.match(page2, /Cadeira &lt;Gamer&gt;/, 'nome escapado');
assert.ok(!page2.includes('<Gamer>'));
assert.match(page2, /Mercado Livre/);
assert.match(page2, /class="rm"/);
assert.match(page2, /R\$ 599,90/);
assert.equal((await fetch(`${local}/img/${mid}`)).status, 200, 'imagem da oferta manual');
assert.equal((await post({ name: 'x', link: 'javascript:alert(1)' })).status, 400, 'link inválido');
assert.equal((await post({ name: '', link: 'https://a.com' })).status, 400, 'sem nome');
assert.equal((await post({ name: 'x', link: 'https://a.com', image: 'ftp://a/b.jpg' })).status, 400, 'imagem inválida');
assert.equal((await post('não é json')).status, 400);
assert.equal((await post({ name: 'x', link: 'https://a.com' }, { Origin: 'http://evil.com' })).status, 403, 'origem externa');
assert.equal(
  (await fetch(`${local}/api/manual`, { method: 'POST', headers: { 'Content-Type': 'text/plain' }, body: '{}' })).status,
  415,
);
const hostStatus = await new Promise((resolve, reject) => {
  const rq = http.request(
    { host: '127.0.0.1', port: freePort, path: '/', headers: { Host: 'evil.com' } },
    (rs) => {
      rs.resume();
      resolve(rs.statusCode);
    },
  );
  rq.on('error', reject);
  rq.end();
});
assert.equal(hostStatus, 403, 'Host externo bloqueado');
const saved = JSON.parse(readFileSync(manualFile, 'utf8'));
assert.equal(saved.length, 1);
assert.match(saved[0].text, /\*Cadeira <Gamer>\*/);
await fetch(`${local}/api/manual/${mid}`, { method: 'DELETE' });
assert.equal(JSON.parse(readFileSync(manualFile, 'utf8')).length, 0, 'remoção');
assert.ok(!(await (await fetch(`${local}/`)).text()).includes('Cadeira'));

child.kill('SIGTERM');
await new Promise((r) => child.on('exit', r));

server.close();
console.log('OK: todos os testes passaram');
