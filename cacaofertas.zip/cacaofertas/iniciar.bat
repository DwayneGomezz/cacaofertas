@echo off
cd /d "%~dp0"
title CacaOfertas
where node >nul 2>nul
if errorlevel 1 (
  echo O Node.js nao foi encontrado. Instale a versao LTS em https://nodejs.org e abra este arquivo de novo.
  pause
  exit /b 1
)
if not exist ".env" (
  echo Falta o arquivo .env nesta pasta. Copie o .env.example para .env e preencha.
  pause
  exit /b 1
)
echo Iniciando o CacaOfertas... deixe esta janela aberta.
echo Para parar, feche a janela ou aperte Ctrl+C.
start "" /min cmd /c "timeout /t 5 /nobreak >nul && start http://localhost:3000"
call npm start
echo.
echo O bot parou. Aperte uma tecla para fechar.
pause >nul
