#!/usr/bin/env node
// CaçaOfertas: bot de ofertas de afiliado Shopee (Brasil).
// Busca produtos na API oficial (Shopee Affiliate Open API), filtra, evita repetidos
// e envia para Telegram e/ou para um webhook (ponte para WhatsApp).
// Sem dependências externas: precisa só de Node.js 20.12+.

import { createHash } from 'node:crypto';
import { readFile, writeFile, rename } from 'node:fs/promises';
import { setTimeout as sleep } from 'node:timers/promises';
import { resolve } from 'node:path';
import http from 'node:http';

const argv = new Set(process.argv.slice(2));
const ONCE = argv.has('--once');
const DRY = argv.has('--dry-run') || process.env.DRY_RUN === '1';

// ---------- configuração ----------
const env = process.env;
const num = (k, d) => {
  const raw = env[k];
  if (raw === undefined || raw.trim() === '') return d;
  const v = Number(raw.replace(',', '.'));
  return Number.isFinite(v) ? v : d;
};
const list = (k) =>
  (env[k] || '')
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean);

const cfg = {
  name: (env.BOT_NAME || 'CaçaOfertas').trim().slice(0, 40) || 'CaçaOfertas',
  appId: (env.SHOPEE_APP_ID || '').trim(),
  secret: (env.SHOPEE_APP_SECRET || '').trim(),
  endpoint: env.SHOPEE_ENDPOINT || 'https://open-api.affiliate.shopee.com.br/graphql',
  keywords: list('KEYWORDS'),
  // Ordenações consultadas na Shopee: 1 relevância, 2 mais vendidos, 3 maior preço, 4 menor preço, 5 maior comissão.
  // O bot junta os resultados de todas e escolhe os melhores pela nota (RANK_BY).
  sortTypes: (() => {
    const l = list('SORT_TYPES').map(Number).filter((n) => Number.isInteger(n) && n >= 1 && n <= 5);
    if (l.length) return [...new Set(l)];
    const one = num('SORT_TYPE', NaN);
    return Number.isInteger(one) && one >= 1 && one <= 5 ? [one] : [2, 5];
  })(),
  rankBy: (env.RANK_BY || 'score').trim().toLowerCase(), // score | commission | sales | discount | api
  pageSize: Math.min(500, Math.max(1, Math.floor(num('PAGE_SIZE', 50)))),
  maxPages: Math.max(1, Math.floor(num('MAX_PAGES', 4))),
  // Se as primeiras páginas já foram enviadas, o bot continua paginando até este limite
  maxPagesLimit: Math.max(1, Math.floor(num('MAX_PAGES_LIMIT', 20))),
  minCommission: num('MIN_COMMISSION_PERCENT', 0),
  minSales: num('MIN_SALES', 0),
  minRating: num('MIN_RATING', 0),
  minPrice: num('MIN_PRICE', 0),
  maxPrice: num('MAX_PRICE', Infinity),
  maxPerRun: Math.max(1, Math.floor(num('MAX_PER_RUN', 20))),
  intervalMin: Math.max(1, num('INTERVAL_MINUTES', 10)),
  delaySec: Math.max(0, num('DELAY_SECONDS', 5)),
  dedupeDays: Math.max(1, num('DEDUPE_DAYS', 7)),
  activeHours: (env.ACTIVE_HOURS || '').trim(), // ex.: 8-22 (horário de Brasília)
  tgApi: (env.TELEGRAM_API || 'https://api.telegram.org').replace(/\/$/, ''),
  tgToken: (env.TELEGRAM_BOT_TOKEN || '').trim(),
  tgChats: list('TELEGRAM_CHAT_IDS'),
  webhook: (env.WEBHOOK_URL || '').trim(),
  statePath: env.STATE_FILE || './state.json',
  // Página de ofertas para copiar e colar no WhatsApp. Use PAGE_FILE=off para desligar.
  pageFile: (env.PAGE_FILE ?? 'ofertas.html').trim(),
  pageMax: Math.max(5, Math.floor(num('PAGE_MAX_ITEMS', 200))),
  // Porta da página local (http://localhost:PORTA). 0 desliga e usa só o arquivo ofertas.html.
  port: Math.max(0, Math.floor(num('PAGE_PORT', 3000))),
  manualPath: env.MANUAL_FILE || './manuais.json', // ofertas adicionadas à mão (Mercado Livre, Amazon...)
};
cfg.maxPagesLimit = Math.max(cfg.maxPages, cfg.maxPagesLimit);
const pageOn = cfg.pageFile !== '' && cfg.pageFile.toLowerCase() !== 'off';

const log = (...a) => console.log(new Date().toISOString(), ...a);

function validate() {
  const errs = [];
  if (!cfg.appId) errs.push('SHOPEE_APP_ID não definido');
  if (!cfg.secret) errs.push('SHOPEE_APP_SECRET não definido');
  const hasTg = cfg.tgToken && cfg.tgChats.length > 0;
  if (!DRY && !hasTg && !cfg.webhook && !pageOn) {
    errs.push('Nenhum destino ativo: use PAGE_FILE, TELEGRAM_BOT_TOKEN + TELEGRAM_CHAT_IDS ou WEBHOOK_URL');
  }
  if (cfg.tgToken && cfg.tgChats.length === 0) errs.push('TELEGRAM_CHAT_IDS vazio');
  if (!['score', 'commission', 'sales', 'discount', 'api'].includes(cfg.rankBy)) {
    errs.push('RANK_BY inválido (use score, commission, sales, discount ou api)');
  }
  if (cfg.activeHours && !/^\d{1,2}-\d{1,2}$/.test(cfg.activeHours)) {
    errs.push('ACTIVE_HOURS inválido (use o formato 8-22)');
  }
  return errs;
}

// ---------- Shopee ----------
const sha256 = (s) => createHash('sha256').update(s).digest('hex');

const QUERY = `query ($keyword: String, $sortType: Int, $page: Int, $limit: Int) {
  productOfferV2(keyword: $keyword, sortType: $sortType, page: $page, limit: $limit) {
    nodes {
      itemId productName price priceMin priceMax commissionRate sales
      imageUrl shopName productLink offerLink ratingStar priceDiscountRate
    }
    pageInfo { page limit hasNextPage }
  }
}`;

async function shopee(variables) {
  const body = JSON.stringify({ query: QUERY, variables });
  const ts = Math.floor(Date.now() / 1000);
  // Assinatura: SHA256(appId + timestamp + corpo exato da requisição + secret)
  const signature = sha256(`${cfg.appId}${ts}${body}${cfg.secret}`);
  const res = await fetch(cfg.endpoint, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `SHA256 Credential=${cfg.appId}, Timestamp=${ts}, Signature=${signature}`,
    },
    body,
    signal: AbortSignal.timeout(20000),
  });
  const text = await res.text();
  let json;
  try {
    json = JSON.parse(text);
  } catch {
    throw new TransientError(`Shopee HTTP ${res.status}: resposta que não é JSON`);
  }
  if (json.errors?.length) {
    const e = json.errors[0];
    const code = e?.extensions?.code ?? 'n/d';
    const err = new Error(`Shopee recusou a consulta: ${e?.message || 'erro'} (código ${code})`);
    // 10020 = credencial/assinatura inválida; não adianta tentar de novo
    if (res.status >= 500 || res.status === 429) throw new TransientError(err.message);
    throw err;
  }
  if (!res.ok) {
    const msg = `Shopee HTTP ${res.status}`;
    if (res.status >= 500 || res.status === 429) throw new TransientError(msg);
    throw new Error(msg);
  }
  return json.data;
}

class TransientError extends Error {}

async function withRetry(fn, tries = 3) {
  let last;
  for (let i = 0; i < tries; i++) {
    try {
      return await fn();
    } catch (e) {
      last = e;
      const transient = e instanceof TransientError || e?.name === 'TimeoutError' || e?.cause?.code;
      if (!transient || i === tries - 1) break;
      await sleep(2000 * 2 ** i);
    }
  }
  throw last;
}

function normalize(n) {
  if (!n || n.itemId == null || !n.offerLink) return null; // sem offerLink não há comissão
  const rate = Number(n.commissionRate);
  // A API devolve a taxa como fração (0.10 = 10%); aceitamos também 10 = 10%
  const commissionPct = !Number.isFinite(rate) ? 0 : rate <= 1 ? rate * 100 : rate;
  const price = Number(n.price);
  const pMin = Number(n.priceMin);
  const pMax = Number(n.priceMax);
  const disc = Number(n.priceDiscountRate);
  return {
    id: String(n.itemId),
    name: String(n.productName || 'Produto Shopee'),
    price: Number.isFinite(price) ? price : NaN,
    priceMin: Number.isFinite(pMin) && pMin > 0 ? pMin : NaN,
    priceMax: Number.isFinite(pMax) && pMax > 0 ? pMax : NaN,
    commissionPct,
    sales: Number.isFinite(Number(n.sales)) ? Number(n.sales) : 0,
    rating: Number.isFinite(Number(n.ratingStar)) ? Number(n.ratingStar) : 0,
    discount: Number.isFinite(disc) && disc > 0 && disc < 100 ? Math.round(disc) : 0,
    image: n.imageUrl || '',
    shop: n.shopName || '',
    link: n.offerLink,
  };
}

function passes(p) {
  const price = Number.isFinite(p.price) ? p.price : p.priceMin;
  if (p.commissionPct < cfg.minCommission) return false;
  if (p.sales < cfg.minSales) return false;
  if (p.rating > 0 && p.rating < cfg.minRating) return false;
  if (Number.isFinite(price) && (price < cfg.minPrice || price > cfg.maxPrice)) return false;
  return true;
}

// Nota de 0 a 1: desconto, popularidade (vendas), comissão e avaliação.
function score(p) {
  const disc = Math.min(p.discount, 90) / 90;
  const sales = Math.min(Math.log10(1 + p.sales) / 5, 1);
  const comm = Math.min(p.commissionPct / 20, 1);
  const rate = p.rating > 0 ? p.rating / 5 : 0.6;
  return 0.35 * disc + 0.3 * sales + 0.2 * comm + 0.15 * rate;
}

function rank(list) {
  const by = {
    score,
    commission: (p) => p.commissionPct,
    sales: (p) => p.sales,
    discount: (p) => p.discount,
  }[cfg.rankBy];
  return by ? [...list].sort((a, b) => by(b) - by(a)) : list; // 'api' mantém a ordem da Shopee
}

// ---------- mensagens ----------
const brl = new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' });
const trunc = (s, n) => (s.length > n ? s.slice(0, n - 1).trimEnd() + '…' : s);
const escHtml = (s) =>
  String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

function priceText(p) {
  if (Number.isFinite(p.priceMin) && Number.isFinite(p.priceMax) && p.priceMin !== p.priceMax) {
    return `${brl.format(p.priceMin)} a ${brl.format(p.priceMax)}`;
  }
  const v = Number.isFinite(p.price) ? p.price : p.priceMin;
  return Number.isFinite(v) ? brl.format(v) : 'Veja o preço no link';
}

// style 'html' (Telegram) ou 'wa' (negrito do WhatsApp com *)
function buildMessage(p, style) {
  const name = trunc(p.name, 120);
  const bold = (t) => (style === 'html' ? `<b>${escHtml(t)}</b>` : `*${t}*`);
  const plain = (t) => (style === 'html' ? escHtml(t) : t);
  const lines = [`🔥 ${bold(name)}`, ''];
  lines.push(`💰 ${bold(priceText(p))}${p.discount ? ` (${p.discount}% OFF)` : ''}`);
  const extra = [];
  if (p.rating > 0) extra.push(`⭐ ${p.rating.toFixed(1)}`);
  if (p.sales > 0) extra.push(`🛒 ${p.sales.toLocaleString('pt-BR')} vendidos`);
  if (extra.length) lines.push(extra.join(' · '));
  lines.push('', `🛍️ Comprar: ${plain(p.link)}`);
  return lines.join('\n');
}

// ---------- envio ----------
async function tgCall(method, payload) {
  for (let attempt = 0; attempt < 4; attempt++) {
    const res = await fetch(`${cfg.tgApi}/bot${cfg.tgToken}/${method}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
      signal: AbortSignal.timeout(20000),
    });
    const json = await res.json().catch(() => ({}));
    if (json.ok) return json;
    if (res.status === 429) {
      await sleep(((json.parameters?.retry_after ?? 5) + 0.5) * 1000);
      continue;
    }
    throw new Error(`Telegram ${method}: ${json.description || `HTTP ${res.status}`}`);
  }
  throw new Error(`Telegram ${method}: limite de envio excedido`);
}

async function sendTelegram(p) {
  const text = buildMessage(p, 'html');
  let ok = 0;
  for (const chat of cfg.tgChats) {
    try {
      if (p.image) {
        try {
          await tgCall('sendPhoto', { chat_id: chat, photo: p.image, caption: text, parse_mode: 'HTML' });
          ok++;
          continue;
        } catch (e) {
          log(`foto falhou (${e.message}); enviando só texto`);
        }
      }
      await tgCall('sendMessage', {
        chat_id: chat,
        text,
        parse_mode: 'HTML',
        link_preview_options: { is_disabled: false },
      });
      ok++;
    } catch (e) {
      log(`falha ao enviar para o chat ${chat}: ${e.message}`);
    }
  }
  return ok > 0;
}

async function sendWebhook(p) {
  try {
    const res = await fetch(cfg.webhook, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        text: buildMessage(p, 'wa'),
        imageUrl: p.image,
        link: p.link,
        product: { id: p.id, name: p.name, price: p.price, shop: p.shop },
      }),
      signal: AbortSignal.timeout(20000),
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return true;
  } catch (e) {
    log(`falha no webhook: ${e.message}`);
    return false;
  }
}

// served=true: página servida em localhost (permite copiar/baixar a imagem); false: arquivo local
function renderPage(items, served = false) {
  const cards = items
    .map((it) => {
      const wa = 'https://wa.me/?text=' + encodeURIComponent(it.text);
      const imgSrc = served ? `/img/${encodeURIComponent(it.id)}` : it.image;
      const imgBtns = !it.image
        ? ''
        : served
          ? `<button class="copyimg">Copiar imagem</button>
      <a href="${escHtml(imgSrc)}" download="oferta-${escHtml(it.id)}.jpg">Baixar imagem</a>`
          : `<a target="_blank" rel="noopener" href="${escHtml(it.image)}">Ver imagem</a>`;
      return `<article class="card" data-id="${escHtml(it.id)}">
  ${it.image ? `<img src="${escHtml(imgSrc)}" alt="" loading="lazy" referrerpolicy="no-referrer">` : ''}
  <div class="body">
    ${it.store ? `<p class="store">${escHtml(it.store)}</p>` : ''}
    <h2>${escHtml(trunc(it.name, 100))}</h2>
    <p class="price">${escHtml(it.price)}</p>
    <textarea readonly rows="7">${escHtml(it.text)}</textarea>
    <div class="btns">
      <button class="copy">Copiar texto</button>
      <a class="wa" target="_blank" rel="noopener" href="${escHtml(wa)}">Abrir no WhatsApp</a>
      ${imgBtns}
      <button class="done">Marcar como postado</button>
      ${served && it.manual ? '<button class="rm">Remover</button>' : ''}
    </div>
  </div>
</article>`;
    })
    .join('\n');
  const when = new Date().toLocaleString('pt-BR', { timeZone: 'America/Sao_Paulo' });
  return `<!doctype html>
<html lang="pt-BR"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>${escHtml(cfg.name)}</title>
<style>
body{font-family:system-ui,Segoe UI,Arial,sans-serif;background:#f4f4f5;color:#18181b;margin:0;padding:16px}
header{max-width:760px;margin:0 auto 16px}
h1{margin:0 0 4px;font-size:22px}
.sub{color:#52525b;font-size:14px;margin:0}
.card{max-width:760px;margin:0 auto 14px;background:#fff;border-radius:12px;padding:14px;display:flex;gap:14px;box-shadow:0 1px 3px rgba(0,0,0,.12)}
.card img{width:150px;height:150px;object-fit:cover;border-radius:8px;flex:none;background:#e4e4e7}
.body{flex:1;min-width:0}
h2{font-size:16px;margin:0 0 4px}
.price{margin:0 0 8px;color:#c2410c;font-weight:700}
textarea{width:100%;box-sizing:border-box;font:14px/1.4 system-ui,Arial,sans-serif;border:1px solid #d4d4d8;border-radius:8px;padding:8px;resize:vertical}
.btns{display:flex;flex-wrap:wrap;gap:8px;margin-top:8px}
button,.btns a{font:600 14px system-ui,Arial,sans-serif;padding:8px 12px;border-radius:8px;border:1px solid #d4d4d8;background:#fff;color:#18181b;cursor:pointer;text-decoration:none}
.copy{background:#ea580c;color:#fff;border-color:#ea580c}
.wa{background:#16a34a;color:#fff;border-color:#16a34a}
.card.done{opacity:.45}
.store{font-size:12px;color:#52525b;margin:0 0 2px;text-transform:uppercase;letter-spacing:.04em}
.manual{max-width:760px;margin:0 auto 14px;background:#fff;border-radius:12px;padding:12px 14px;box-shadow:0 1px 3px rgba(0,0,0,.12)}
.manual summary{cursor:pointer;font-weight:700}
.manual label{display:block;margin:10px 0 0;font-size:13px;font-weight:600}
.manual input,.manual select{width:100%;box-sizing:border-box;margin-top:4px;padding:8px;border:1px solid #d4d4d8;border-radius:8px;font:14px system-ui,Arial,sans-serif}
.manual .hint{font-size:12px;color:#52525b;margin:8px 0 0}
#manual-msg{margin-left:8px;color:#b91c1c;font-size:13px}
@media(max-width:560px){.card{flex-direction:column}.card img{width:100%;height:200px}}
</style></head><body>
<header><h1>${escHtml(cfg.name)}</h1>
<p class="sub">Atualizado em ${escHtml(when)} (aperte F5 para ver as novas). ${
    served
      ? 'Para mandar com foto: clique em Copiar imagem e cole no grupo; depois clique em Copiar texto e cole na legenda.'
      : 'Copie o texto e cole no grupo; para mandar a foto, clique com o botão direito na imagem e copie.'
  }</p></header>
${served ? MANUAL_FORM(items.length === 0) : ''}
${cards || '<p style="text-align:center;color:#52525b">Nenhuma oferta ainda. Aguarde o próximo ciclo do bot.</p>'}
<script>
document.querySelectorAll('.card').forEach(function(c){
  var id=c.dataset.id,done=false;
  try{done=localStorage.getItem('done:'+id)==='1'}catch(e){}
  if(done)c.classList.add('done');
  c.querySelector('.copy').onclick=function(ev){
    var ta=c.querySelector('textarea');ta.select();var ok=false;
    try{ok=document.execCommand('copy')}catch(e){}
    if(!ok&&navigator.clipboard)navigator.clipboard.writeText(ta.value);
    var b=ev.target;b.textContent='Copiado!';setTimeout(function(){b.textContent='Copiar texto'},1500);
  };
  var rm=c.querySelector('.rm');
  if(rm)rm.onclick=async function(){
    if(!confirm('Remover esta oferta?'))return;
    await fetch('/api/manual/'+encodeURIComponent(id),{method:'DELETE'});
    location.reload();
  };
  var ci=c.querySelector('.copyimg');
  if(ci)ci.onclick=async function(ev){
    var b=ev.target,old=b.textContent;
    try{
      var blob=await (await fetch('/img/'+encodeURIComponent(id))).blob();
      var bmp=await createImageBitmap(blob);
      var cv=document.createElement('canvas');cv.width=bmp.width;cv.height=bmp.height;
      cv.getContext('2d').drawImage(bmp,0,0);
      var png=await new Promise(function(r){cv.toBlob(r,'image/png')});
      await navigator.clipboard.write([new ClipboardItem({'image/png':png})]);
      b.textContent='Imagem copiada!';
    }catch(e){b.textContent='Não deu: use Baixar imagem'}
    setTimeout(function(){b.textContent=old},2500);
  };
  c.querySelector('.done').onclick=function(){
    c.classList.toggle('done');
    try{localStorage.setItem('done:'+id,c.classList.contains('done')?'1':'0')}catch(e){}
  };
});
var mf=document.getElementById('manual-form');
if(mf)mf.onsubmit=async function(ev){
  ev.preventDefault();
  var msg=document.getElementById('manual-msg');msg.textContent='Salvando...';
  try{
    var r=await fetch('/api/manual',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(Object.fromEntries(new FormData(mf)))});
    var j=await r.json().catch(function(){return {}});
    if(r.ok){location.reload()}else{msg.textContent=j.error||'Erro ao salvar'}
  }catch(e){msg.textContent='Erro de conexão'}
};
</script></body></html>`;
}

const MANUAL_FORM = (open) => `<details class="manual"${open ? ' open' : ''}>
<summary>➕ Adicionar oferta manual (Mercado Livre, Amazon...)</summary>
<form id="manual-form">
<label>Loja <select name="store"><option>Mercado Livre</option><option>Amazon</option><option>Outra loja</option></select></label>
<label>Nome do produto <input name="name" required maxlength="200"></label>
<label>Preço (ex.: 129,90) <input name="price" maxlength="40"></label>
<label>Link de afiliado <input name="link" type="url" required placeholder="https://..."></label>
<label>Endereço da imagem (opcional) <input name="image" type="url" placeholder="https://..."></label>
<p class="hint">Gere o link no painel de afiliados da loja. Para a imagem: botão direito na foto do produto, <b>Copiar endereço da imagem</b>.</p>
<p><button class="copy" type="submit">Adicionar à lista</button><span id="manual-msg"></span></p>
</form></details>`;

async function loadManual() {
  try {
    const l = JSON.parse(await readFile(cfg.manualPath, 'utf8'));
    return Array.isArray(l) ? l : [];
  } catch (e) {
    if (e.code !== 'ENOENT') {
      log(`${cfg.manualPath} ilegível (${e.message}); guardando cópia`);
      await rename(cfg.manualPath, `${cfg.manualPath}.bak`).catch(() => {});
    }
    return [];
  }
}

async function saveManual(list) {
  const tmp = `${cfg.manualPath}.tmp`;
  await writeFile(tmp, JSON.stringify(list));
  await rename(tmp, cfg.manualPath);
}

// Escritas das ofertas manuais passam por uma fila, para dois cliques seguidos não se atropelarem
let manualQueue = Promise.resolve();
function withManual(fn) {
  const run = manualQueue.then(fn);
  manualQueue = run.catch(() => {});
  return run;
}

async function pageItems(state) {
  const manual = await loadManual();
  return [...state.page, ...manual].sort((a, b) => (b.ts || 0) - (a.ts || 0));
}

const STORES = ['Mercado Livre', 'Amazon', 'Outra loja'];

function cleanUrl(v, required) {
  const t = String(v ?? '').trim();
  if (!t) return required ? null : '';
  if (t.length > 2000) return null;
  try {
    const u = new URL(t);
    return u.protocol === 'http:' || u.protocol === 'https:' ? u.href : null;
  } catch {
    return null;
  }
}

class InputError extends Error {}

function buildManualItem(body) {
  const name = String(body?.name ?? '').trim().slice(0, 200);
  if (!name) throw new InputError('Informe o nome do produto');
  const link = cleanUrl(body?.link, true);
  if (!link) throw new InputError('Link de afiliado inválido (precisa começar com http:// ou https://)');
  const image = cleanUrl(body?.image, false);
  if (image === null) throw new InputError('Endereço da imagem inválido (precisa começar com http:// ou https://)');
  const store = STORES.includes(body?.store) ? body.store : '';
  let price = String(body?.price ?? '').trim().slice(0, 40);
  if (/^\d/.test(price)) price = `R$ ${price}`;
  const lines = [`🔥 *${name}*`, ''];
  if (price) lines.push(`💰 *${price}*`);
  if (store) lines.push(`🏬 ${store}`);
  lines.push('', `🛍️ Comprar: ${link}`);
  return {
    id: `m${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`,
    ts: Date.now(),
    manual: true,
    store,
    name,
    price: price || 'Veja o preço no link',
    text: lines.join('\n'),
    image,
    link,
  };
}

async function writePage(state) {
  const tmp = `${cfg.pageFile}.tmp`;
  await writeFile(tmp, renderPage(await pageItems(state)));
  await rename(tmp, cfg.pageFile);
}

async function addToPage(p, state) {
  try {
    state.page.unshift({
      id: p.id,
      ts: Date.now(),
      store: 'Shopee',
      name: p.name,
      price: priceText(p),
      text: buildMessage(p, 'wa'),
      image: p.image,
      link: p.link,
    });
    state.page = state.page.slice(0, cfg.pageMax);
    await writePage(state);
    return true;
  } catch (e) {
    log(`falha ao atualizar a página de ofertas: ${e.message}`);
    return false;
  }
}

async function deliver(p, state) {
  if (DRY) {
    console.log('--- [dry-run] ---\n' + buildMessage(p, 'wa') + '\n');
    return true;
  }
  const results = [];
  if (cfg.tgToken && cfg.tgChats.length) results.push(await sendTelegram(p));
  if (cfg.webhook) results.push(await sendWebhook(p));
  if (pageOn) results.push(await addToPage(p, state));
  return results.some(Boolean);
}

// ---------- estado (evita repetir produto) ----------
async function loadState() {
  try {
    const s = JSON.parse(await readFile(cfg.statePath, 'utf8'));
    return {
      sent: s.sent && typeof s.sent === 'object' ? s.sent : {},
      cursor: Number(s.cursor) || 0,
      page: Array.isArray(s.page) ? s.page : [],
    };
  } catch (e) {
    if (e.code !== 'ENOENT') {
      log(`state.json ilegível (${e.message}); guardando cópia e recomeçando`);
      await rename(cfg.statePath, `${cfg.statePath}.bak`).catch(() => {});
    }
    return { sent: {}, cursor: 0, page: [] };
  }
}

async function saveState(state) {
  const tmp = `${cfg.statePath}.tmp`;
  await writeFile(tmp, JSON.stringify(state));
  await rename(tmp, cfg.statePath);
}

function prune(state) {
  const limit = Date.now() - cfg.dedupeDays * 86400000;
  for (const [id, t] of Object.entries(state.sent)) if (t < limit) delete state.sent[id];
}

// ---------- servidor local da página ----------
async function readBody(req, max = 20000) {
  let n = 0;
  const chunks = [];
  for await (const c of req) {
    n += c.length;
    if (n > max) throw new InputError('Requisição grande demais');
    chunks.push(c);
  }
  return Buffer.concat(chunks).toString('utf8');
}

function startServer() {
  if (!pageOn || cfg.port <= 0 || ONCE || DRY) return null;
  const allowedHosts = [`localhost:${cfg.port}`, `127.0.0.1:${cfg.port}`];
  const reply = (res, code, type, body) => {
    res.writeHead(code, { 'Content-Type': type, 'Cache-Control': 'no-store' });
    res.end(body);
  };
  const json = (res, code, obj) => reply(res, code, 'application/json; charset=utf-8', JSON.stringify(obj));

  const srv = http.createServer(async (req, res) => {
    try {
      // Proteção: só aceita acessos feitos pelo próprio computador, direto no endereço local
      if (!allowedHosts.includes(String(req.headers.host || '').toLowerCase())) {
        return reply(res, 403, 'text/plain', 'acesso negado');
      }
      const url = new URL(req.url, 'http://localhost');
      const isWrite = req.method === 'POST' || req.method === 'DELETE';
      if (isWrite && req.headers.origin && !allowedHosts.map((h) => `http://${h}`).includes(req.headers.origin)) {
        return reply(res, 403, 'text/plain', 'acesso negado');
      }

      if (req.method === 'GET' && (url.pathname === '/' || url.pathname === '/ofertas')) {
        const st = await loadState();
        return reply(res, 200, 'text/html; charset=utf-8', renderPage(await pageItems(st), true));
      }

      if (req.method === 'POST' && url.pathname === '/api/manual') {
        if (!String(req.headers['content-type'] || '').startsWith('application/json')) {
          return json(res, 415, { error: 'Tipo de conteúdo inválido' });
        }
        let item;
        try {
          item = buildManualItem(JSON.parse(await readBody(req)));
        } catch (e) {
          if (e instanceof InputError) return json(res, 400, { error: e.message });
          if (e instanceof SyntaxError) return json(res, 400, { error: 'Dados inválidos' });
          throw e;
        }
        await withManual(async () => saveManual([item, ...(await loadManual())].slice(0, cfg.pageMax)));
        log(`oferta manual adicionada: ${item.name}`);
        return json(res, 200, { ok: true, id: item.id });
      }

      const del = /^\/api\/manual\/([^/]+)$/.exec(url.pathname);
      if (req.method === 'DELETE' && del) {
        const id = decodeURIComponent(del[1]);
        await withManual(async () => saveManual((await loadManual()).filter((x) => x.id !== id)));
        return json(res, 200, { ok: true });
      }

      const m = /^\/img\/([^/]+)$/.exec(url.pathname);
      if (req.method === 'GET' && m) {
        // Só serve imagens de ofertas que estão na página (não é um proxy aberto)
        const st = await loadState();
        const it = (await pageItems(st)).find((x) => x.id === decodeURIComponent(m[1]));
        if (!it || !it.image) return reply(res, 404, 'text/plain', 'não encontrada');
        const r = await fetch(it.image, { signal: AbortSignal.timeout(20000) });
        const type = r.headers.get('content-type') || '';
        if (!r.ok || !type.startsWith('image/')) return reply(res, 502, 'text/plain', 'imagem indisponível');
        const buf = Buffer.from(await r.arrayBuffer());
        if (buf.length > 8_000_000) return reply(res, 502, 'text/plain', 'imagem grande demais');
        res.writeHead(200, { 'Content-Type': type, 'Cache-Control': 'public, max-age=86400' });
        return res.end(buf);
      }
      reply(res, 404, 'text/plain', 'não encontrada');
    } catch (e) {
      log(`erro no servidor local: ${e.message}`);
      reply(res, 500, 'text/plain', 'erro interno');
    }
  });
  srv.on('error', (e) => log(`página local indisponível (${e.code || e.message}); use o arquivo ${cfg.pageFile}`));
  srv.listen(cfg.port, '127.0.0.1', () => log(`página disponível em http://localhost:${cfg.port}`));
  return srv;
}

// ---------- horário ativo ----------
function inActiveHours() {
  if (!cfg.activeHours) return true;
  const [a, b] = cfg.activeHours.split('-').map(Number);
  const h =
    Number(
      new Intl.DateTimeFormat('en-GB', { hour: '2-digit', hour12: false, timeZone: 'America/Sao_Paulo' }).format(
        new Date(),
      ),
    ) % 24;
  return a <= b ? h >= a && h < b : h >= a || h < b;
}

// ---------- ciclo ----------
async function runOnce() {
  if (!inActiveHours()) {
    log(`fora do horário ativo (${cfg.activeHours}); aguardando`);
    return;
  }
  const state = await loadState();
  prune(state);

  const kws = cfg.keywords.length ? cfg.keywords : [''];
  const keyword = kws[state.cursor % kws.length];
  state.cursor = (state.cursor + 1) % kws.length;
  log(`buscando ofertas${keyword ? ` para "${keyword}"` : ' (sem palavra-chave)'}`);

  // Junta candidatos de todas as ordenações e páginas, sem repetir, e escolhe os melhores pela nota.
  const pool = new Map();
  let lastErr = null;
  let requests = 0;
  for (const sortType of cfg.sortTypes) {
    try {
      for (let page = 1; page <= cfg.maxPagesLimit; page++) {
        // Depois das páginas básicas, só continua se ainda faltarem ofertas novas
        if (page > cfg.maxPages && pool.size >= cfg.maxPerRun) break;
        const data = await withRetry(() =>
          shopee({ keyword: keyword || null, sortType, page, limit: cfg.pageSize }),
        );
        requests++;
        const conn = data?.productOfferV2;
        if (!conn) throw new Error('Resposta da Shopee sem o campo productOfferV2');
        for (const node of conn.nodes ?? []) {
          const p = normalize(node);
          if (!p || pool.has(p.id) || state.sent[p.id] || !passes(p)) continue;
          pool.set(p.id, p);
        }
        if (!conn.pageInfo?.hasNextPage) break;
        await sleep(300);
      }
    } catch (e) {
      lastErr = e;
      log(`falha ao consultar a Shopee (ordenação ${sortType}): ${e.message}`);
    }
  }
  if (pool.size === 0 && lastErr) throw lastErr;
  const picked = rank([...pool.values()]).slice(0, cfg.maxPerRun);
  log(`${pool.size} ofertas novas encontradas em ${requests} consultas; enviando as ${picked.length} melhores`);

  if (!picked.length) {
    log('nenhuma oferta nova que passe nos filtros');
    await saveState(state);
    return;
  }

  let sent = 0;
  for (const p of picked) {
    if (await deliver(p, state)) {
      sent++;
      if (!DRY) {
        state.sent[p.id] = Date.now();
        await saveState(state); // grava a cada envio: se cair, não reenvia
      }
    }
    const external = (cfg.tgToken && cfg.tgChats.length > 0) || cfg.webhook;
    if (!DRY && external && cfg.delaySec > 0 && p !== picked[picked.length - 1]) await sleep(cfg.delaySec * 1000);
  }
  await saveState(state);
  log(`ciclo concluído: ${sent}/${picked.length} ofertas enviadas`);
  if (pageOn && sent > 0 && !DRY) log(`página atualizada: ${resolve(cfg.pageFile)}`);
}

process.on('unhandledRejection', (e) => log(`erro inesperado: ${e?.message || e}`));
process.on('uncaughtException', (e) => log(`erro inesperado: ${e?.message || e}`));

async function main() {
  const errs = validate();
  if (errs.length) {
    console.error('Configuração inválida:\n - ' + errs.join('\n - '));
    process.exit(1);
  }
  const ac = new AbortController();
  const stop = () => {
    log('encerrando...');
    ac.abort();
  };
  process.on('SIGINT', stop);
  process.on('SIGTERM', stop);

  const server = startServer();
  log(`${cfg.name}: bot iniciado${DRY ? ' (dry-run)' : ''}${ONCE ? ' (uma execução)' : `, intervalo de ${cfg.intervalMin} min`}`);
  let failed = false;
  while (!ac.signal.aborted) {
    try {
      await runOnce();
      failed = false;
    } catch (e) {
      failed = true;
      log(`erro no ciclo: ${e.message}`);
    }
    if (ONCE) break;
    try {
      await sleep(cfg.intervalMin * 60000, undefined, { signal: ac.signal });
    } catch {
      break;
    }
  }
  server?.closeAllConnections?.();
  server?.close();
  if (ONCE && failed) process.exit(1);
}

main();
