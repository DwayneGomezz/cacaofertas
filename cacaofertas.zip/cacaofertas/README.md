# CaçaOfertas: bot de ofertas Shopee

Busca produtos na **API oficial de afiliados da Shopee**, filtra por comissão, vendas, nota e preço, evita repetir produtos e entrega as ofertas prontas em uma **página para copiar e colar no WhatsApp**, no **Telegram** e/ou num **webhook**. O nome que aparece na página pode ser trocado em `BOT_NAME` no `.env`. Sem dependências externas: só Node.js 20.12 ou mais novo.

## 1. Instalar

1. Instale o Node.js (nodejs.org, versão LTS).
2. Abra o terminal na pasta do projeto e copie a configuração:
   - Windows (PowerShell): `copy .env.example .env`
   - Mac/Linux: `cp .env.example .env`
3. Edite o `.env` (bloco de notas serve).

## 2. Credenciais

- **Shopee:** no painel de afiliados, seção *Open API*, copie o **App ID** e o **App Secret** para `SHOPEE_APP_ID` e `SHOPEE_APP_SECRET`. O acesso à Open API depende de aprovação da Shopee.
- **Telegram (opcional, só se for usar):** fale com o `@BotFather`, crie um bot e copie o token para `TELEGRAM_BOT_TOKEN`. Adicione o bot como administrador do seu canal ou grupo e coloque o id (`@nomedocanal` ou `-100...`) em `TELEGRAM_CHAT_IDS`.

## 3. WhatsApp: copiar e colar

Com `npm start` rodando, abra no navegador o endereço **http://localhost:3000**. Cada oferta aparece como um cartão com foto e texto pronto:

- **Copiar imagem:** copia a foto; cole no grupo do WhatsApp (Ctrl+V).
- **Copiar texto:** copia a mensagem; cole na legenda da foto ou como mensagem.
- **Baixar imagem:** salva a foto no computador, caso você prefira anexar pelo clipe do WhatsApp.
- **Abrir no WhatsApp:** abre o WhatsApp já com o texto escrito, e você escolhe o grupo.
- **Marcar como postado:** apaga o cartão para você saber o que já enviou.

O link curto da Shopee não mostra a foto na prévia do WhatsApp, por isso a imagem precisa ser enviada junto, por um dos botões acima. Aperte **F5** para ver as ofertas novas. Esse modo não tem risco de banimento, porque quem envia é você.

### Mercado Livre, Amazon e outras lojas (oferta manual)

No topo da página há o quadro **Adicionar oferta manual**. Gere o link de afiliado no painel da própria loja (Mercado Livre: gerador de links; Amazon: barra do Associates), e preencha: loja, nome, preço, link de afiliado e, se quiser foto, o endereço da imagem (botão direito na foto do produto, *Copiar endereço da imagem*). O cartão aparece junto com os da Shopee, com os mesmos botões, e tem um botão **Remover**. As ofertas manuais ficam salvas em `manuais.json`.

O bot não acessa Mercado Livre nem Amazon sozinho: o link vem sempre do painel oficial de afiliados de cada loja.

O bot também grava o arquivo `ofertas.html` na pasta (usado por `npm run once`, sem os botões de imagem). Se a porta 3000 estiver ocupada, mude `PAGE_PORT` no `.env`.

## 4. Testar antes de automatizar

```
npm test        # teste automático com servidores simulados (não usa internet)
npm run dry     # busca ofertas reais e só mostra as mensagens, sem enviar
npm run once    # faz um ciclo real e encerra
npm start       # roda em loop, a cada INTERVAL_MINUTES
```

Comece sempre pelo `npm run dry` para conferir se as credenciais e os filtros trazem o que você quer.

## 5. Deixar rodando

- **Mais fácil no Windows:** dê duplo clique em **`iniciar.bat`**. Ele liga o bot e abre a página no navegador sozinho. Deixe a janela preta aberta.
- **Abrir junto com o Windows:** aperte `Win + R`, digite `shell:startup` e Enter; copie um atalho do `iniciar.bat` para essa pasta (botão direito no arquivo, *Criar atalho*, e arraste para lá).

- **Simples:** `npm start` numa janela do terminal (para com Ctrl+C).
- **Sempre ligado:** use um servidor/VPS com `pm2` (`npm i -g pm2`, depois `pm2 start src/bot.js --name shopee-bot --node-args="--env-file=.env"`).

## Modo melhores ofertas (padrão)

Sem filtro e sem nicho: a cada ciclo (10 minutos) o bot consulta a Shopee ordenando por mais vendidos e por maior comissão, junta os resultados, remove o que já foi enviado e escolhe os **melhores pela nota**, que combina desconto (35%), vendas (30%), comissão (20%) e avaliação (15%). Entram até `MAX_PER_RUN` ofertas por ciclo (padrão 20). Se as primeiras páginas já foram enviadas, ele pagina mais fundo (até `MAX_PAGES_LIMIT`) para achar ofertas novas.

Para postar mais ou menos, mude `MAX_PER_RUN`. Para escolher só por comissão, use `RANK_BY=commission`. Para voltar a filtrar por nicho ou qualidade, preencha `KEYWORDS`, `MIN_SALES`, `MIN_RATING` e os demais.

Lembre que a Shopee tem milhões de produtos: o bot envia as melhores ofertas a cada ciclo, não todas. E como você posta na mão, muitas ofertas por ciclo acumulam na página mais rápido do que dá para publicar.

## Como funciona

- Alterna entre as `KEYWORDS` a cada ciclo; sem palavras-chave, busca em todos os nichos.
- Só envia produtos que têm `offerLink` (o link de afiliado já rastreado devolvido pela API).
- `state.json` guarda o que já foi enviado (por `DEDUPE_DAYS` dias). Se o bot cair, ele não reenvia.
- Se a foto falhar, envia só o texto. Erros temporários da Shopee (instabilidade, limite) têm nova tentativa automática; credencial inválida aparece no log com o código do erro.
- `ACTIVE_HOURS=8-22` evita mensagens de madrugada (horário de Brasília).

## WhatsApp

O envio para grupos de WhatsApp não tem uma via oficial simples. O bot oferece o **webhook**: a cada oferta ele faz um `POST` em `WEBHOOK_URL` com JSON `{ text, imageUrl, link, product }`, e o texto já vem no formato do WhatsApp (negrito com `*`). Você liga isso a um gateway de WhatsApp que controla.

Atenção: ferramentas não oficiais de WhatsApp violam os termos do serviço e o número pode ser banido. Use um número secundário e envie com moderação, ou prefira a API oficial (WhatsApp Business) quando fizer sentido.

## Regras da Shopee

Confira o contrato do programa de afiliados antes de automatizar: divulgue apenas com o seu link e respeite as regras sobre spam e frequência de divulgação.
